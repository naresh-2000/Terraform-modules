const AWS   = require('aws-sdk');
const Async = require('async');
const Sharp = require('sharp');
    var gm = require('gm').subClass({
    imageMagick: true
});

// AWS.config.update({
//     accessKeyId: 'AKIAJ2XHT4NBXA5EVEGA',
//     secretAccessKey: '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',
//     region: 'us-east-1'
// });

const S3        = new AWS.S3();
const MAX_WIDTH = 256;

let Bucket  = 'suuchigriddev';
let Key     = '';
let payload = new Object();

exports.handler = function (event, context, callback) {
    Bucket  = event.Records[0].s3.bucket.name;
    Key     = event.Records[0].s3.object.key;
    
    Key     = Key.replace(/\+/g, ' ');
    Key     = decodeURIComponent(Key);

    var isAiFile = false;
    
    if (Key.indexOf('suuchi_documents') === -1) {
        console.warn('AWS Lambda execution stopped explicitly');

    } else {
        const steps = new Array();
    
        steps.push(downloadMetadata);
        steps.push(validateContentType);
        steps.push(downloadObject);
        steps.push(processObject);
        steps.push(uploadObject);
    
        Async.waterfall(steps, function (err, result) {
            if (err) {
                console.warn(`${err.statusCode} ${err.code} - ${err.message}`);
            } else {
                console.info('AWS Lambda executed successfully');
            }
        });
    }
};

const downloadMetadata = (callback) => {
    console.info('Download object metadata from S3 Bucket..');
    console.info('- Bucket:', Bucket);
    console.info('- Key:', Key);
    
    S3.headObject({ Bucket, Key }, callback);
};

const validateContentType = (metadata, callback) => {
    console.info('Validating object metadata..');
    console.info('- ContentType:', metadata.ContentType);

    const allowedContentType = [
        'image/png',
        'image/jpg',
        'image/jpeg',
        'image/svg+xml',
        'application/postscript'
    ];
    const contentType = metadata.ContentType || '';
    payload['isAiFile'] = contentType === 'application/postscript'

    if (allowedContentType.indexOf(contentType) === -1) {
        console.warn('ContentType not supported');

    } else {
        payload['ContentType'] = contentType;
        callback(null);

    }
};

const downloadObject = (callback) => {
    console.info('Downloading object content as buffer from S3 Bucket..');

    S3.getObject({ Bucket, Key }, callback);
};

const processObject = (result, callback) => {
    if (payload.isAiFile) {
        console.log('converting to ai');
        convertAiFile(result, callback)
    } else if (payload.ContentType.indexOf('svg') === -1) {
        resizeObject(result, callback);
    } else {
        convertObject(result, callback);
    }
};

const resizeObject = (result, callback) => {
    console.info(`Resizing object image to ${MAX_WIDTH} width..`);
    
    Sharp(result.Body)
        .resize(MAX_WIDTH)
        .toBuffer(function (err, data, info) {
        if (err) {
            console.warn(`${err.statusCode} ${err.code} - ${err.message}`);

        } else {
            payload['Key'] = Key
                .replace('suuchi_documents', 'resized_images');
            callback(null, data);

        }
    });
};

const convertObject = (result, callback) => {
    console.info('Converting object to PNG..');

    Sharp(result.Body)
        .metadata(function (err, metadata) {     
        if (err) {
            console.warn(`${err.statusCode} ${err.code} - ${err.message}`);

        } else {
            let density = metadata.density * MAX_WIDTH / metadata.width;
            
            // Check boundary value
            density = (density <= 2400) ? density : 2400; 
            density = (density >= 10) ? density : 10;
    
            console.info(`- Upscale density from ${metadata.density} to ${density}`);
            
            Sharp(result.Body, { density })
                .png()
                .toBuffer(function (err, data, info) {
                if (err) {
                    console.warn(`${err.statusCode} ${err.code} - ${err.message}`);

                } else {
                    payload['Key'] = Key
                        .replace('suuchi_documents', 'converted_images')
                        .replace('.svg', '.png');
                    payload['ContentType'] = 'image/png';
                    callback(null, data);

                }
            });
            
        }
    });
};

const convertAiFile = (result, callback) => {
    console.log('Converting .ai file to .png');

    payload['Key'] = Key
    .replace('suuchi_documents', 'ai_converted_files')
    .replace('.ai', '.png');
    payload['ContentType'] = 'image/png';

    gm(result.Body).toBuffer('png', callback);
};

const uploadObject = (Body, callback) => {
    console.info('Uploading object back to S3 Bucket..');
    console.info('- Key:', payload.Key);
    console.info('- ContentType:', payload.ContentType);
    
    S3.putObject({
        Bucket,
        Key: payload.Key,
        Body,
        ContentType: payload.ContentType,
        ACL: 'public-read'
    }, callback);
};
